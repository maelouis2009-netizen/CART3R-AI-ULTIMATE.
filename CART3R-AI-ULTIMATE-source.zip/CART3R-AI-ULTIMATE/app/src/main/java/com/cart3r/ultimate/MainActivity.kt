package com.cart3r.ultimate

import android.net.Uri
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

private val Bg = Color(0xFF050505)
private val Panel = Color(0xFF171719)
private val Panel2 = Color(0xFF202024)
private val Pink = Color(0xFFFF4081)
private val Muted = Color(0xFF96969F)
private val White = Color(0xFFF7F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 5, 5)
        window.navigationBarColor = android.graphics.Color.rgb(5, 5, 5)
        setContent { Cart3rApp() }
    }
}

private enum class Screen { HOME, CODE, VIDEO, SETTINGS }
private data class ChatLine(val text: String, val fromUser: Boolean)

@Composable
private fun Cart3rApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("cart3r_settings", Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var prompt by remember { mutableStateOf("") }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "http://127.0.0.1:8080/v1/chat/completions") ?: "http://127.0.0.1:8080/v1/chat/completions") }
    var model by remember { mutableStateOf(prefs.getString("model", "local-model") ?: "local-model") }
    var chat by remember {
        mutableStateOf(runCatching {
            val saved = prefs.getString("chat", null)
            if (saved.isNullOrBlank()) emptyList() else {
                val arr = JSONArray(saved)
                (0 until arr.length()).map { i ->
                    val item = arr.getJSONObject(i)
                    ChatLine(item.optString("text"), item.optBoolean("fromUser"))
                }
            }
        }.getOrDefault(emptyList()).ifEmpty { listOf(ChatLine("Bienvenue dans CART3R AI. Configure un serveur llama.cpp compatible OpenAI dans Réglages, puis envoie ton premier message.", false)) })
    }
    var videos by remember {
        mutableStateOf(runCatching {
            val arr = JSONArray(prefs.getString("videos", "[]"))
            (0 until arr.length()).mapNotNull { i -> runCatching { Uri.parse(arr.getString(i)) }.getOrNull() }
        }.getOrDefault(emptyList()))
    }
    var busy by remember { mutableStateOf(false) }
    var engineStatus by remember { mutableStateOf("MOTEUR NON TESTÉ") }
    val scope = rememberCoroutineScope()
    LaunchedEffect(chat) {
        val arr = JSONArray()
        chat.takeLast(100).forEach { arr.put(JSONObject().put("text", it.text).put("fromUser", it.fromUser)) }
        prefs.edit().putString("chat", arr.toString()).apply()
    }
    LaunchedEffect(videos) {
        val arr = JSONArray()
        videos.forEach { arr.put(it.toString()) }
        prefs.edit().putString("videos", arr.toString()).apply()
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { picked ->
        picked.forEach { uri ->
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
        if (picked.isNotEmpty()) videos = (videos + picked).distinct()
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Pink, onBackground = White, onSurface = White)) {
        Scaffold(containerColor = Bg, bottomBar = { BottomBar(screen) { screen = it } }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    Screen.HOME -> HomeScreen(onCode = { screen = Screen.CODE }, onVideo = { screen = Screen.VIDEO }, onSettings = { screen = Screen.SETTINGS })
                    Screen.CODE -> CodeScreen(chat, prompt, { prompt = it }, busy, {
                        val q = prompt.trim()
                        if (q.isNotEmpty() && !busy) {
                            chat = chat + ChatLine(q, true)
                            prompt = ""
                            busy = true
                            scope.launch {
                                val answer = withContext(Dispatchers.IO) { callLocalModel(endpoint, model, q, chat.dropLast(1)) }
                                chat = chat + ChatLine(answer, false)
                                engineStatus = if (answer.startsWith("Connexion impossible") || answer.startsWith("Réponse invalide")) "MOTEUR À VÉRIFIER" else "MOTEUR CONNECTÉ"
                                busy = false
                            }
                        }
                    })
                    Screen.VIDEO -> VideoScreen(videos, { picker.launch(arrayOf("video/*")) }, { uri -> videos = videos - uri }, { uri ->
                        runCatching {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "video/*")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(intent)
                        }
                    })
                    Screen.SETTINGS -> SettingsScreen(endpoint, { endpoint = it }, model, { model = it }, engineStatus, {
                        prefs.edit().putString("endpoint", endpoint.trim()).putString("model", model.trim()).apply()
                        engineStatus = "CONFIGURATION ENREGISTRÉE"
                    }, {
                        scope.launch {
                            engineStatus = "TEST EN COURS…"
                            val result = withContext(Dispatchers.IO) { testLocalEndpoint(endpoint) }
                            engineStatus = result
                        }
                    })
                }
            }
        }
    }
}

private fun callLocalModel(endpoint: String, model: String, prompt: String, history: List<ChatLine>): String {
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 120000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", "Tu es CART3R, un assistant de programmation utile. Réponds en français sauf demande contraire."))
        history.takeLast(12).forEach { line -> messages.put(JSONObject().put("role", if (line.fromUser) "user" else "assistant").put("content", line.text)) }
        messages.put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject().put("model", model.ifBlank { "local-model" }).put("messages", messages).put("temperature", 0.7).put("stream", false)
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) "Connexion impossible (HTTP $code). Vérifie que llama.cpp tourne et que l'adresse est correcte.\n$response"
        else JSONObject(response).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")?.takeIf { it.isNotBlank() }
            ?: "Réponse invalide : le serveur n'a pas renvoyé choices[0].message.content."
    } catch (e: Exception) {
        "Connexion impossible : ${e.localizedMessage ?: "erreur réseau"}.\n\nVérifie l'adresse du serveur et démarre llama.cpp avec une API compatible OpenAI."
    } finally { connection?.disconnect() }
}

private fun testLocalEndpoint(endpoint: String): String = try {
    val url = endpoint.substringBefore("/chat/completions") + "/models"
    val c = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = 5000; readTimeout = 5000; requestMethod = "GET" }
    val code = c.responseCode
    c.disconnect()
    if (code in 200..499) "SERVEUR ACCESSIBLE" else "SERVEUR À VÉRIFIER (HTTP $code)"
} catch (_: Exception) { "SERVEUR INJOIGNABLE" }

@Composable
private fun Header(subtitle: String = "YOUR PERSONAL AI WORKSPACE") {
    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Pink), contentAlignment = Alignment.Center) {
                Text("C", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 23.sp)
            }
            Spacer(Modifier.width(11.dp))
            Column {
                Text("CART3R AI", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, letterSpacing = 1.sp)
                Text("ULTIMATE", color = Pink, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 3.sp)
            }
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(9.dp).clip(CircleShape).background(Color(0xFFFFB74D)))
            Spacer(Modifier.width(6.dp))
            Text("SETUP", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(18.dp))
        Text(subtitle, color = Muted, fontSize = 10.sp, letterSpacing = 1.8.sp)
    }
}

@Composable
private fun HomeScreen(onCode: () -> Unit, onVideo: () -> Unit, onSettings: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Header()
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text("Build. Create.\nGo beyond.", color = White, fontSize = 34.sp, lineHeight = 39.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(10.dp))
                Text("Ton espace de création assisté par IA.", color = Muted, fontSize = 14.sp)
                Spacer(Modifier.height(24.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("WORKSPACE", color = White, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp)
                    Spacer(Modifier.weight(1f)); Text("02 MODULES", color = Pink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                FeatureCard("01", "CODE LAB", "Assistant de programmation", "Écris, comprends et améliore ton code.", Icons.Default.Code, onCode)
                Spacer(Modifier.height(12.dp))
                FeatureCard("02", "STUDIO VIDÉO", "Espace de création vidéo", "Importe et organise tes clips.", Icons.Default.Movie, onVideo)
                Spacer(Modifier.height(20.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().clickable { onSettings() }) {
                    Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tune, null, tint = Pink)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text("Configuration", color = White, fontWeight = FontWeight.SemiBold); Text("Moteurs IA et préférences", color = Muted, fontSize = 12.sp) }
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("VERSION 0.3.0 • BETA BUILD", color = Color(0xFF5F5F68), fontSize = 9.sp, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun FeatureCard(number: String, title: String, sub: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(43.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFF30202A)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Pink, modifier = Modifier.size(23.dp)) }
                Spacer(Modifier.weight(1f)); Text(number, color = Color(0xFF666670), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(18.dp))
            Text(title, color = White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
            Text(sub, color = Pink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(7.dp))
            Text(description, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun CodeScreen(chat: List<ChatLine>, prompt: String, onPrompt: (String) -> Unit, busy: Boolean, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("CODE LAB / AI ASSISTANT")
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Code Lab", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.weight(1f)); Surface(color = Color(0xFF332A1B), shape = CircleShape) { Text(if (busy) "THINKING…" else "LOCAL API", Modifier.padding(horizontal = 10.dp, vertical = 5.dp), color = if (busy) Color(0xFFFFC56B) else Pink, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
        }
        Text("Assistant de développement", Modifier.padding(start = 20.dp, top = 4.dp), color = Muted, fontSize = 12.sp)
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(chat) { line ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (line.fromUser) Color(0xFF3A1D2A) else Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                        Text(line.text, Modifier.padding(14.dp), color = White, fontSize = 13.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(14.dp).clip(RoundedCornerShape(18.dp)).background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(value = prompt, onValueChange = onPrompt, modifier = Modifier.weight(1f).padding(10.dp), textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 13.sp), cursorBrush = androidx.compose.ui.graphics.SolidColor(Pink), decorationBox = { inner -> if (prompt.isEmpty()) Text("Demande quelque chose…", color = Muted, fontSize = 13.sp); inner() })
            IconButton(onClick = onSend, enabled = !busy, modifier = Modifier.size(42.dp).clip(CircleShape).background(if (busy) Panel2 else Pink)) { if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Pink, strokeWidth = 2.dp) else Icon(Icons.Default.ArrowUpward, null, tint = Color.Black) }
        }
    }
}

@Composable
private fun VideoScreen(videos: List<Uri>, onImport: () -> Unit, onRemove: (Uri) -> Unit, onPlay: (Uri) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("STUDIO VIDÉO / WORKSPACE")
        Text("Studio Vidéo", Modifier.padding(horizontal = 20.dp), color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text("Bibliothèque et préparation de projets", Modifier.padding(start = 20.dp, top = 4.dp), color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(22.dp))
        Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp).clickable { onImport() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.AddToPhotos, null, tint = Pink, modifier = Modifier.size(38.dp))
                Spacer(Modifier.height(12.dp)); Text("Importer des vidéos", color = White, fontWeight = FontWeight.Bold)
                Text("Sélectionne des clips depuis ton téléphone", color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("PROJETS / MÉDIAS (${videos.size})", Modifier.padding(horizontal = 20.dp), color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        if (videos.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.VideoLibrary, null, tint = Color(0xFF4C4C55), modifier = Modifier.size(42.dp)); Spacer(Modifier.height(10.dp)); Text("Aucun média pour le moment", color = Muted, fontSize = 12.sp) } }
        } else {
            LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(videos) { uri -> Surface(color = Panel, shape = RoundedCornerShape(12.dp)) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Movie, null, tint = Pink); Spacer(Modifier.width(10.dp)); Text(displayName(LocalContext.current, uri), Modifier.weight(1f).clickable { onPlay(uri) }, color = White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp); IconButton(onClick = { onPlay(uri) }) { Icon(Icons.Default.PlayArrow, "Lire", tint = Pink) }; IconButton(onClick = { onRemove(uri) }) { Icon(Icons.Default.Close, "Retirer", tint = Muted) } } } }
            }
        }
    }
}

private fun displayName(context: Context, uri: Uri): String {
    return runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment ?: "Clip vidéo"
}

@Composable
private fun SettingsScreen(endpoint: String, onEndpoint: (String) -> Unit, model: String, onModel: (String) -> Unit, status: String, onSave: () -> Unit, onTest: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("SYSTEM / CONFIGURATION")
        Text("Configuration", Modifier.padding(horizontal = 20.dp), color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(16.dp))
        Text("CODE LAB / SERVEUR LOCAL", Modifier.padding(horizontal = 20.dp), color = Pink, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Text("Adresse API compatible OpenAI", Modifier.padding(start = 20.dp, top = 12.dp, bottom = 6.dp), color = White, fontSize = 12.sp)
        OutlinedTextField(value = endpoint, onValueChange = onEndpoint, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 12.sp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Pink, unfocusedBorderColor = Panel2, focusedTextColor = White, unfocusedTextColor = White))
        Text("Nom du modèle", Modifier.padding(start = 20.dp, top = 12.dp, bottom = 6.dp), color = White, fontSize = 12.sp)
        OutlinedTextField(value = model, onValueChange = onModel, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 12.sp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Pink, unfocusedBorderColor = Panel2, focusedTextColor = White, unfocusedTextColor = White))
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onSave, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Pink, contentColor = Color.Black)) { Text("Enregistrer") }
            OutlinedButton(onClick = onTest, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = White)) { Text("Tester") }
        }
        Text(status, Modifier.padding(horizontal = 20.dp), color = if (status.contains("ACCESSIBLE") || status.contains("ENREGISTRÉE") || status.contains("CONNECTÉ")) Color(0xFF8BE0A1) else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        SettingRow("Moteur Code Lab", "API locale llama.cpp / OpenAI compatible", Icons.Default.Memory)
        SettingRow("Modèle local", "À charger séparément au format GGUF", Icons.Default.Storage)
        SettingRow("Studio Vidéo", "Import et bibliothèque locale de clips", Icons.Default.Movie)
        SettingRow("Confidentialité", "Les requêtes partent vers l'adresse configurée", Icons.Default.Security)
        Text("IMPORTANT", Modifier.padding(start = 20.dp, top = 16.dp), color = Pink, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text("Cette application ne télécharge pas de modèle automatiquement. Pour une IA entièrement locale, installe et démarre un serveur llama.cpp compatible OpenAI sur le téléphone, puis indique son adresse ici. Le modèle GGUF doit être obtenu séparément et sa taille dépend de la mémoire disponible.", Modifier.padding(20.dp), color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun SettingRow(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp).clip(RoundedCornerShape(14.dp)).background(Panel).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Pink); Spacer(Modifier.width(13.dp)); Column { Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold); Text(value, color = Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun BottomBar(current: Screen, navigate: (Screen) -> Unit) {
    NavigationBar(containerColor = Color(0xFF101012), contentColor = White) {
        val entries = listOf(Triple(Screen.HOME, "Home", Icons.Default.Home), Triple(Screen.CODE, "Code", Icons.Default.Code), Triple(Screen.VIDEO, "Vidéo", Icons.Default.Movie), Triple(Screen.SETTINGS, "Réglages", Icons.Default.Settings))
        entries.forEach { (screen, label, icon) ->
            NavigationBarItem(selected = current == screen, onClick = { navigate(screen) }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Pink, selectedTextColor = Pink, indicatorColor = Color(0xFF35202A), unselectedIconColor = Muted, unselectedTextColor = Muted))
        }
    }
}
