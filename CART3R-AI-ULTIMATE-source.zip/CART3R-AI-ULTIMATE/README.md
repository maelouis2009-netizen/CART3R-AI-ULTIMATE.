# CART3R AI ULTIMATE — v0.3.0

Projet d'application Android native en Kotlin + Jetpack Compose, interface sombre avec accent rose.

## Fonctionnalités réellement présentes

- Navigation Home / Code Lab / Studio Vidéo / Réglages.
- Code Lab : chat avec historique local (100 derniers messages) et appel HTTP non-streaming vers une API compatible OpenAI, comme `llama.cpp --server`.
- Configuration persistante de l'URL du serveur et du nom de modèle.
- Test de disponibilité du serveur via son endpoint `/v1/models`.
- Studio Vidéo : import de plusieurs vidéos via le sélecteur Android, conservation des autorisations, bibliothèque persistante, ouverture des clips dans le lecteur vidéo installé et suppression de la liste.
- Aucune inscription ni clé API n'est nécessaire pour utiliser l'interface. Un serveur IA reste nécessaire pour obtenir des réponses du modèle.

## Limites à connaître

Cette version est une bêta fonctionnelle de l'interface et de la connexion à un moteur externe, pas une suite de création vidéo complète.

- Le modèle GGUF et le moteur `llama.cpp` ne sont pas embarqués. Il faut démarrer séparément un serveur compatible OpenAI et télécharger un modèle adapté au téléphone.
- L'IA n'est donc pas autonome dès la première ouverture. Sans serveur configuré, Code Lab affiche une erreur de connexion explicite.
- Studio Vidéo gère et lit les clips, mais ne réalise pas encore de montage multipiste, d'export, ni de génération vidéo par IA.
- Aucun service cloud de génération vidéo n'est configuré. Les services gratuits peuvent imposer quotas, files d'attente ou restrictions.
- L'APK n'a pas été compilé ni testé sur appareil dans l'environnement de préparation. Le workflow GitHub Actions ci-dessous effectue la compilation dans un environnement Android CI.

## Configuration Code Lab

1. Démarrer un serveur local compatible avec l'API OpenAI, par exemple `llama.cpp` server.
2. Ouvrir Réglages dans l'application.
3. Saisir l'URL complète Chat Completions, par exemple `http://127.0.0.1:8080/v1/chat/completions` si le serveur tourne sur le même téléphone.
4. Saisir l'identifiant de modèle attendu par le serveur, enregistrer puis tester.

Si le serveur tourne sur un autre appareil du réseau local, utiliser son adresse IP privée à la place de `127.0.0.1`. Ne pas exposer un serveur local à Internet sans authentification et protections adaptées.

## Obtenir l'APK sans installer Android Studio

Le dépôt contient `.github/workflows/android.yml` :

1. Créer un dépôt GitHub (privé conseillé) et y importer le contenu de ce dossier.
2. Ouvrir l'onglet **Actions** du dépôt.
3. Sélectionner **Build Android APK**, puis **Run workflow**.
4. Attendre la fin du job et télécharger l'artefact `cart3r-ai-debug-apk` dans les artefacts du workflow.
5. Extraire l'APK sur le téléphone et l'ouvrir pour l'installer. Android peut demander d'autoriser temporairement l'installation depuis le navigateur ou le gestionnaire de fichiers.

Le workflow compile un APK debug non signé pour publication. Pour une diffusion publique, il faudra créer une clé de signature privée et configurer une build release signée.

## Informations techniques

- Application ID : `com.cart3r.ultimate`
- Minimum Android : API 26 (Android 8.0)
- Compile / target SDK : 35
- Version : `0.3.0` (versionCode 3)
